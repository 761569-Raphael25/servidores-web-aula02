# servidores-web-aula02

## Identificação
- **Nome completo:** RAPHAEL PEREIRA RODRIGUES
- **RA:** 761569
- **Curso:** Ciência da Computação
- **Disciplina:** Desenvolvimento de Aplicações WEB

## Resumo da aula
A aula abordou servidores e ambientes Web, o modelo de requisição e resposta,
servidores locais e remotos, ambientes de desenvolvimento e produção e
versionamento de código com Git/GitHub.

Um servidor web combina hardware e software para receber requisições e entregar
páginas, arquivos ou serviços. No fluxo Web, o navegador atua como cliente,
envia uma requisição e recebe uma resposta do servidor.

Também foi apresentada a diferença entre servidor local, usado para
desenvolvimento e testes, e servidor remoto, usado para disponibilizar
aplicações pela Internet.

## Arquivos criados
- [Exercício 1 - Criar página HTML simples](01_Exercicio_HTML/index.html)
- [Exercício 2 - Identificar cliente, servidor e resposta](02_Exercicio_Cliente_Servidor/index.html)
- [Exercício 3 - Servidor local x servidor remoto](03_Exercicio_Local_Remoto/index.html)

## O que aprendi
- O que é um servidor web;
- Como funciona o modelo de requisição e resposta;
- A diferença entre cliente e servidor;
- A diferença entre servidor local e servidor remoto;
- A diferença entre desenvolvimento e produção;
- A importância do versionamento com Git/GitHub.

## Publicação no GitHub
O repositório solicitado na aula deve se chamar:

`servidores-web-aula02`

Depois de criar o repositório, adicione os três arquivos HTML e este README.

> Os prints solicitados pelo professor devem ser feitos pelo aluno após a publicação:
> 1. print da página do GitHub;
> 2. print de pelo menos um arquivo HTML aberto no navegador.

## Observação
Os campos entre colchetes devem ser substituídos pelos dados do aluno antes da entrega.
